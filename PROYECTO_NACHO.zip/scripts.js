document.addEventListener('DOMContentLoaded', function() {
    const cart = [];
    const cartItemsElement = document.getElementById('cart-items');
    const cartTotalElement = document.getElementById('cart-total');

    function updateCart() {
        cartItemsElement.innerHTML = '';
        let total = 0;
        cart.forEach(item => {
            const li = document.createElement('li');
            li.textContent = `${item.product} - $${item.price.toFixed(2)}`;
            cartItemsElement.appendChild(li);
            total += item.price;
        });
        cartTotalElement.textContent = total.toFixed(2);
    }

    const buttons = document.querySelectorAll('.product-card button');
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const product = this.getAttribute('data-product');
            const price = parseFloat(this.getAttribute('data-price'));
            cart.push({ product, price });
            updateCart();
            alert('Producto añadido al carrito');
        });
    });

    document.getElementById('checkout').addEventListener('click', function() {
        if (cart.length === 0) {
            alert('El carrito está vacío');
        } else {
            alert('Compra realizada con éxito');
            cart.length = 0;
            updateCart();
        }
    });
});
